Rise of the Republic - Placeholder file.
This will be replaced with the full game content.